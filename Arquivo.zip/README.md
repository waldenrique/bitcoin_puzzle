# Instructions

Select your desired min, max for the private key, and the wallets (public key)

Example:

```
const min = 0x2126875fd00000000
const max = 0x3ffffffffffffffff

const wallets = ['13zb1hQbWVsc2S7ZTZnP2G4undNNpdh5so']
```

Run:

`$ npm install`

And:

`$ node btc.js`
